const Footer = () => {
  return (
    <footer>
      <p>Pie Stars 2024. All Rights Reserved.</p>
    </footer>
  )
}

export default Footer
